package com.example.rediscachecodeMysql.controller;

import com.example.rediscachecodeMysql.model.User;
import com.example.rediscachecodeMysql.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    private final Logger logger= LoggerFactory.getLogger(UserController.class);
    @Autowired
    private UserService userService;

    @GetMapping("/user/{id}")
    @Cacheable(value = "users",key = "#id",unless = "#result.id<5")
    public User getUser(@PathVariable long id) {
        logger.debug(">> UserController :/user/{id} call : ",id);
        return userService.getUser(id);
    }

    @PostMapping("/user")
    public User create(@RequestBody User user) {
        logger.debug(">> User Controller :/user call: ",user.toString());
        return userService.create(user);
    }

    @GetMapping("/users")
    public List<User> getAll(){
        logger.debug(">> User Controller Get All Users");
        return userService.getAll();
    }

    @PutMapping("/update")
    @CachePut(value = "users",key = "#user.id")
    public User updateUser(@RequestBody User user){
        logger.info("updateUserID: "+user.toString());
        logger.debug(">> User Controller /update call : " ,user.toString());
        return userService.update(user);
    }

    @DeleteMapping("/delete/{id}")
    @CacheEvict(value = "users",allEntries = false,key = "#id")
    public List<User> deleteUser(@PathVariable long id){
        logger.debug(">> User Controller /delete/{id} call : ",id);
        userService.delete(id);
        return userService.getAll();
    }

}
